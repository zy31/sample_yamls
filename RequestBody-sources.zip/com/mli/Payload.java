
package com.mli;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "loanDetails",
    "borrowerDetails",
    "acceleratedCriticalIllness"
})
public class Payload implements Serializable
{

    @JsonProperty("loanDetails")
    private LoanDetails loanDetails;
    @JsonProperty("borrowerDetails")
    private BorrowerDetails borrowerDetails;
    @JsonProperty("acceleratedCriticalIllness")
    private AcceleratedCriticalIllness acceleratedCriticalIllness;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -508400319731257497L;

    @JsonProperty("loanDetails")
    public LoanDetails getLoanDetails() {
        return loanDetails;
    }

    @JsonProperty("loanDetails")
    public void setLoanDetails(LoanDetails loanDetails) {
        this.loanDetails = loanDetails;
    }

    public Payload withLoanDetails(LoanDetails loanDetails) {
        this.loanDetails = loanDetails;
        return this;
    }

    @JsonProperty("borrowerDetails")
    public BorrowerDetails getBorrowerDetails() {
        return borrowerDetails;
    }

    @JsonProperty("borrowerDetails")
    public void setBorrowerDetails(BorrowerDetails borrowerDetails) {
        this.borrowerDetails = borrowerDetails;
    }

    public Payload withBorrowerDetails(BorrowerDetails borrowerDetails) {
        this.borrowerDetails = borrowerDetails;
        return this;
    }

    @JsonProperty("acceleratedCriticalIllness")
    public AcceleratedCriticalIllness getAcceleratedCriticalIllness() {
        return acceleratedCriticalIllness;
    }

    @JsonProperty("acceleratedCriticalIllness")
    public void setAcceleratedCriticalIllness(AcceleratedCriticalIllness acceleratedCriticalIllness) {
        this.acceleratedCriticalIllness = acceleratedCriticalIllness;
    }

    public Payload withAcceleratedCriticalIllness(AcceleratedCriticalIllness acceleratedCriticalIllness) {
        this.acceleratedCriticalIllness = acceleratedCriticalIllness;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Payload withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("loanDetails", loanDetails).append("borrowerDetails", borrowerDetails).append("acceleratedCriticalIllness", acceleratedCriticalIllness).append("additionalProperties", additionalProperties).toString();
    }

}
