
package com.mli;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "soaCorrelationId",
    "soaAppId"
})
public class Header implements Serializable
{

    @JsonProperty("soaCorrelationId")
    private String soaCorrelationId;
    @JsonProperty("soaAppId")
    private String soaAppId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 2834628803075876962L;

    @JsonProperty("soaCorrelationId")
    public String getSoaCorrelationId() {
        return soaCorrelationId;
    }

    @JsonProperty("soaCorrelationId")
    public void setSoaCorrelationId(String soaCorrelationId) {
        this.soaCorrelationId = soaCorrelationId;
    }

    public Header withSoaCorrelationId(String soaCorrelationId) {
        this.soaCorrelationId = soaCorrelationId;
        return this;
    }

    @JsonProperty("soaAppId")
    public String getSoaAppId() {
        return soaAppId;
    }

    @JsonProperty("soaAppId")
    public void setSoaAppId(String soaAppId) {
        this.soaAppId = soaAppId;
    }

    public Header withSoaAppId(String soaAppId) {
        this.soaAppId = soaAppId;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Header withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("soaCorrelationId", soaCorrelationId).append("soaAppId", soaAppId).append("additionalProperties", additionalProperties).toString();
    }

}
