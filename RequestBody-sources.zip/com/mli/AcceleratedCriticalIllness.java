
package com.mli;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "isRequired",
    "code",
    "tenure",
    "SAPercentage",
    "benefitType"
})
public class AcceleratedCriticalIllness implements Serializable
{

    @JsonProperty("isRequired")
    private String isRequired;
    @JsonProperty("code")
    private String code;
    @JsonProperty("tenure")
    private String tenure;
    @JsonProperty("SAPercentage")
    private String sAPercentage;
    @JsonProperty("benefitType")
    private String benefitType;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 8868267836821321384L;

    @JsonProperty("isRequired")
    public String getIsRequired() {
        return isRequired;
    }

    @JsonProperty("isRequired")
    public void setIsRequired(String isRequired) {
        this.isRequired = isRequired;
    }

    public AcceleratedCriticalIllness withIsRequired(String isRequired) {
        this.isRequired = isRequired;
        return this;
    }

    @JsonProperty("code")
    public String getCode() {
        return code;
    }

    @JsonProperty("code")
    public void setCode(String code) {
        this.code = code;
    }

    public AcceleratedCriticalIllness withCode(String code) {
        this.code = code;
        return this;
    }

    @JsonProperty("tenure")
    public String getTenure() {
        return tenure;
    }

    @JsonProperty("tenure")
    public void setTenure(String tenure) {
        this.tenure = tenure;
    }

    public AcceleratedCriticalIllness withTenure(String tenure) {
        this.tenure = tenure;
        return this;
    }

    @JsonProperty("SAPercentage")
    public String getSAPercentage() {
        return sAPercentage;
    }

    @JsonProperty("SAPercentage")
    public void setSAPercentage(String sAPercentage) {
        this.sAPercentage = sAPercentage;
    }

    public AcceleratedCriticalIllness withSAPercentage(String sAPercentage) {
        this.sAPercentage = sAPercentage;
        return this;
    }

    @JsonProperty("benefitType")
    public String getBenefitType() {
        return benefitType;
    }

    @JsonProperty("benefitType")
    public void setBenefitType(String benefitType) {
        this.benefitType = benefitType;
    }

    public AcceleratedCriticalIllness withBenefitType(String benefitType) {
        this.benefitType = benefitType;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AcceleratedCriticalIllness withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("isRequired", isRequired).append("code", code).append("tenure", tenure).append("sAPercentage", sAPercentage).append("benefitType", benefitType).append("additionalProperties", additionalProperties).toString();
    }

}
