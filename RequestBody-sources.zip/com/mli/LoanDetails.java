
package com.mli;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "schemeType",
    "sumAssured",
    "interestRate",
    "tenure",
    "coverOption",
    "hasFinancePremium",
    "edc",
    "MPH",
    "maxLifeRegisteredState"
})
public class LoanDetails implements Serializable
{

    @JsonProperty("schemeType")
    private String schemeType;
    @JsonProperty("sumAssured")
    private String sumAssured;
    @JsonProperty("interestRate")
    private String interestRate;
    @JsonProperty("tenure")
    private String tenure;
    @JsonProperty("coverOption")
    private String coverOption;
    @JsonProperty("hasFinancePremium")
    private String hasFinancePremium;
    @JsonProperty("edc")
    private String edc;
    @JsonProperty("MPH")
    private String mPH;
    @JsonProperty("maxLifeRegisteredState")
    private String maxLifeRegisteredState;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 1389996993213162865L;

    @JsonProperty("schemeType")
    public String getSchemeType() {
        return schemeType;
    }

    @JsonProperty("schemeType")
    public void setSchemeType(String schemeType) {
        this.schemeType = schemeType;
    }

    public LoanDetails withSchemeType(String schemeType) {
        this.schemeType = schemeType;
        return this;
    }

    @JsonProperty("sumAssured")
    public String getSumAssured() {
        return sumAssured;
    }

    @JsonProperty("sumAssured")
    public void setSumAssured(String sumAssured) {
        this.sumAssured = sumAssured;
    }

    public LoanDetails withSumAssured(String sumAssured) {
        this.sumAssured = sumAssured;
        return this;
    }

    @JsonProperty("interestRate")
    public String getInterestRate() {
        return interestRate;
    }

    @JsonProperty("interestRate")
    public void setInterestRate(String interestRate) {
        this.interestRate = interestRate;
    }

    public LoanDetails withInterestRate(String interestRate) {
        this.interestRate = interestRate;
        return this;
    }

    @JsonProperty("tenure")
    public String getTenure() {
        return tenure;
    }

    @JsonProperty("tenure")
    public void setTenure(String tenure) {
        this.tenure = tenure;
    }

    public LoanDetails withTenure(String tenure) {
        this.tenure = tenure;
        return this;
    }

    @JsonProperty("coverOption")
    public String getCoverOption() {
        return coverOption;
    }

    @JsonProperty("coverOption")
    public void setCoverOption(String coverOption) {
        this.coverOption = coverOption;
    }

    public LoanDetails withCoverOption(String coverOption) {
        this.coverOption = coverOption;
        return this;
    }

    @JsonProperty("hasFinancePremium")
    public String getHasFinancePremium() {
        return hasFinancePremium;
    }

    @JsonProperty("hasFinancePremium")
    public void setHasFinancePremium(String hasFinancePremium) {
        this.hasFinancePremium = hasFinancePremium;
    }

    public LoanDetails withHasFinancePremium(String hasFinancePremium) {
        this.hasFinancePremium = hasFinancePremium;
        return this;
    }

    @JsonProperty("edc")
    public String getEdc() {
        return edc;
    }

    @JsonProperty("edc")
    public void setEdc(String edc) {
        this.edc = edc;
    }

    public LoanDetails withEdc(String edc) {
        this.edc = edc;
        return this;
    }

    @JsonProperty("MPH")
    public String getMPH() {
        return mPH;
    }

    @JsonProperty("MPH")
    public void setMPH(String mPH) {
        this.mPH = mPH;
    }

    public LoanDetails withMPH(String mPH) {
        this.mPH = mPH;
        return this;
    }

    @JsonProperty("maxLifeRegisteredState")
    public String getMaxLifeRegisteredState() {
        return maxLifeRegisteredState;
    }

    @JsonProperty("maxLifeRegisteredState")
    public void setMaxLifeRegisteredState(String maxLifeRegisteredState) {
        this.maxLifeRegisteredState = maxLifeRegisteredState;
    }

    public LoanDetails withMaxLifeRegisteredState(String maxLifeRegisteredState) {
        this.maxLifeRegisteredState = maxLifeRegisteredState;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public LoanDetails withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("schemeType", schemeType).append("sumAssured", sumAssured).append("interestRate", interestRate).append("tenure", tenure).append("coverOption", coverOption).append("hasFinancePremium", hasFinancePremium).append("edc", edc).append("mPH", mPH).append("maxLifeRegisteredState", maxLifeRegisteredState).append("additionalProperties", additionalProperties).toString();
    }

}
